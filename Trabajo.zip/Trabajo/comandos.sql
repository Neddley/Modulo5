
------CUSTOMER------

	--Modificacion tipo de datos para que el formato ingresado sea igual a los anteriores.
	ALTER TABLE city
			ALTER COLUMN last_update TYPE timestamp(0) without time zone using now();
	ALTER TABLE address
			ALTER COLUMN last_update TYPE timestamp(0) without time zone using now();

	--Modificacion de relacion de llaves foraneas para poder actualizar o eliminar

	ALTER TABLE payment
	DROP CONSTRAINT IF EXISTS payment_customer_id_fkey, 
	ADD CONSTRAINT payment_customer_id_fkey FOREIGN KEY (customer_id)
	REFERENCES customer(customer_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE;

	ALTER TABLE rental
	DROP CONSTRAINT IF EXISTS rental_customer_id_fkey, 
	ADD CONSTRAINT rental_customer_id_fkey FOREIGN KEY (customer_id)
	REFERENCES customer(customer_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE; 
			
--INSERTAR
	--Agrego ciudad chilena y direccion ya que direccion es unica para cada customer
	--voy a revisar tabla country y filtrar
	SELECT * FROM country WHERE country='Chile';-- country id 22
		
	--agregare una ciudad nueva
	INSERT INTO city(city, country_id,last_update)
	VALUES('Punta Arenas',22, current_timestamp);
	
	--creo direccion con correspondiente id
	INSERT INTO address(address, address2, district,city_id, postal_code,phone ,last_update)
	VALUES('2023 Jose Nogueria', null, 'Magallanes', 601, 6200000, 56912345678, current_timestamp);
		
INSERT INTO customer(store_id, first_name, last_name, email, address_id, activebool, create_date, last_update,active) 
VALUES(3,'Emilio', 'Santelices', 'esantelices@gmail.com', 340, 'true', current_date, current_timestamp, 1);

--MODIFICAR
UPDATE customer SET email = 'msmith@sakilacustomer.org' WHERE customer_id=1;

--ELIMINAR
DELETE FROM customer WHERE customer_id=524;


------STAFF------

	--Modificacion tipo de datos para que el formato ingresa sea igual a los anteriores.
	ALTER TABLE store
			ALTER COLUMN last_update TYPE timestamp(0) without time zone using now();		
			
	--Modificacion de relacion de llaves foraneas para poder actualizar o eliminar
	ALTER TABLE store
	DROP CONSTRAINT IF EXISTS store_manager_staff_id_fkey, 
	ADD CONSTRAINT store_manager_staff_id_fkey FOREIGN KEY (manager_staff_id)
	REFERENCES staff(staff_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE;

	ALTER TABLE rental
	DROP CONSTRAINT IF EXISTS rental_staff_id_key, 
	ADD CONSTRAINT rental_staff_id_key FOREIGN KEY (staff_id)
	REFERENCES staff(staff_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE; 
	
	ALTER TABLE payment
	DROP CONSTRAINT IF EXISTS payment_staff_id_fkey, 
	ADD CONSTRAINT payment_staff_id_fkey FOREIGN KEY (staff_id)
	REFERENCES staff(staff_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE;
	
--INSERTAR

	--Agrego ciudad chilena y direccion ya que direccion es unica para cada staff
	--filtro para saber las ciudades disponibles
	SELECT * FROM city WHERE country_id = 22;
	
	--agregare una ciudad nueva
	INSERT INTO city(city, country_id, last_update)
	VALUES('Santiago',22 ,current_timestamp); --city_id 602
	
	--creo direccion con correspondiente id
	INSERT INTO address(address, address2, district,city_id, postal_code,phone ,last_update)
	VALUES('1740 Av. Libertador B. O´higgins',null,'Metropolitana',602 , 6200000, 56911111111, current_timestamp);

INSERT INTO staff(first_name, last_name, address_id, email, store_id, active, username, password, last_update, picture)
VALUES('Ariel', 'Plaza', 607,'Ariel.Plaza@sakilastaff.com', 3, true, 'Ariel', md5('12345678'), current_timestamp, null);

--MODIFICAR
UPDATE staff SET active = false WHERE staff_id=3;

--ELIMINAR
DELETE FROM staff WHERE staff_id=3;


------ACTOR------

	--Modificacion tipo de datos para que el formato ingresa sea igual a los anteriores.
	ALTER TABLE actor
			ALTER COLUMN last_update TYPE timestamp(0) without time zone using now();		
			
	--Modificacion de relacion de llaves foraneas para poder actualizar o eliminar
	ALTER TABLE film_actor
	DROP CONSTRAINT IF EXISTS film_actor_actor_id_fkey, 
	ADD CONSTRAINT film_actor_actor_id_fkey FOREIGN KEY (actor_id)
	REFERENCES actor(actor_id)
	ON UPDATE CASCADE
	ON DELETE CASCADE;
		
--INSERTAR
INSERT INTO actor(first_name, last_name, last_update)
VALUES('Antonio', 'Banderas', current_timestamp);

--MODIFICAR
UPDATE actor SET first_name = 'Antony' WHERE actor_id=134;

--ELIMINAR
DELETE FROM actor WHERE actor_id=20;

------LISTAR------

SELECT rental.rental_id, rental.rental_date as Fecha, customer.customer_id, customer.first_name as Nombre, customer.last_name as Apellido
FROM rental JOIN customer ON rental.customer_id = customer.customer_id
WHERE EXTRACT(YEAR FROM rental.rental_date) = 2005
AND EXTRACT(MONTH FROM rental.rental_date) = 05;

--LISTAR PAYMENT

SELECT payment_id AS Numero, payment_date AS Fecha, amount AS Total
From payment GROUP BY payment_id, payment_date;

--LISTAR FILM

SELECT * FROM film
WHERE release_year = 2006 AND rental_rate > 4.0;

--DICCIONARIO	
SELECT t1.TABLE_NAME AS tabla_nombre, t1.COLUMN_NAME AS columna_nombre, t1.COLUMN_DEFAULT AS columna_defecto,
t1.IS_NULLABLE AS columna_nulo, t1.DATA_TYPE AS columna_tipo_dato,
COALESCE(t1.NUMERIC_PRECISION, t1.CHARACTER_MAXIMUM_LENGTH)AS columna_longitud, PG_CATALOG.COL_DESCRIPTION(t2.OID,
t1. DTD_IDENTIFIER::int)AS columna_description, t1.DOMAIN_NAME AS columna_dominio
FROM INFORMATION_SCHEMA.COLUMNS t1 INNER JOIN PG_CLASS t2 on(t2.RELNAME=t1.TABLE_NAME)
WHERE t1.TABLE_SCHEMA = 'public' ORDER BY t1.TABLE_NAME;